﻿//CSS=theme.css
    
(function() {
  return function() {
    var obj;   
    
    obj = new nexacro.Style_align("center middle");
    this._addCss("MainFrame", "align", obj, ["normal"]);
    this._addCss("Static.sta_POP_TitleBg", "align", obj, ["normal"]);
    this._addCss("Static.sta_POP_AltCfmTitleBg", "align", obj, ["normal"]);
    this._addCss("TextArea.txt_POP_AltCfm", "align", obj, ["normal", "focused"]);
    this._addCss("Button", "align", obj, ["normal"]);
    this._addCss("DatePickerControl", "align", obj, ["normal"]);
    this._addCss("Div", "align", obj, ["normal"]);
    this._addCss("PopupDiv", "align", obj, ["normal"]);
    this._addCss("Button.btn_WF_More", "align", obj, ["normal"]);
    this._addCss("Static.sta_WF_PopCalTitle", "align", obj, ["normal"]);
    this._addCss("Static.sta_WF_MonthCalTitle", "align", obj, ["normal"]);

    obj = new nexacro.Style_background("#ffffffff","","","0","0","0","0","true");
    this._addCss("MainFrame", "background", obj, ["normal"]);
    this._addCss("Form", "background", obj, ["normal"]);
    this._addCss("Static.sta_POP_Bg", "background", obj, ["normal"]);
    this._addCss("Calendar", "background", obj, ["normal"]);
    this._addCss("Combo>#comboedit", "background", obj, ["normal"]);
    this._addCss("Combo>#combolist", "background", obj, ["normal"]);
    this._addCss("DatePickerControl", "background", obj, ["normal"]);
    this._addCss("Edit", "background", obj, ["normal"]);
    this._addCss("Grid>#body", "background", obj, ["normal"]);
    this._addCss("Grid>#controledit", "background", obj, ["normal"]);
    this._addCss("Grid>#controlmaskedit", "background", obj, ["normal"]);
    this._addCss("Grid>#controlcombo>#comboedit", "background", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar", "background", obj, ["normal"]);
    this._addCss("ImageViewer", "background", obj, ["normal"]);
    this._addCss("MaskEdit", "background", obj, ["normal"]);
    this._addCss("Tab", "background", obj, ["normal"]);
    this._addCss("Tabpage", "background", obj, ["normal"]);
    this._addCss("TextArea", "background", obj, ["normal", "mouseover", "focused"]);
    this._addCss("Grid.grd_WF_MonthCal>#body", "background", obj, ["normal"]);
    this._addCss("Static.sta_WF_MonthCalBg", "background", obj, ["normal"]);

    obj = new nexacro.Style_border("0","none","#808080ff","");
    this._addCss("MainFrame", "border", obj, ["normal"]);
    this._addCss("Form", "border", obj, ["normal"]);

    obj = new nexacro.Style_color("#333333");
    this._addCss("MainFrame", "color", obj, ["normal"]);
    this._addCss("Static.sta_GUIDE_Area", "color", obj, ["normal"]);
    this._addCss("Static.sta_GUIDE_Area2", "color", obj, ["normal"]);
    this._addCss("Static.sta_GUIDE_BlackText", "color", obj, ["normal"]);
    this._addCss("Static.sta_GUIDE_BlackBoldText", "color", obj, ["normal"]);

    obj = new nexacro.Style_font("antialias bold 20 Droid Sans");
    this._addCss("MainFrame", "font", obj, ["normal"]);
    this._addCss("Tab", "font", obj, ["normal"]);

    obj = new nexacro.Style_bordertype("normal","0","0","true","true","true","true");
    this._addCss("MainFrame", "bordertype", obj, ["normal"]);
    this._addCss("ChildFrame", "bordertype", obj, ["normal"]);
    this._addCss("Form", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu01", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu02", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu03", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu04", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu05", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu06", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu07", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu08", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu09", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu10", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu11", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu01S", "bordertype", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu02S", "bordertype", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu03S", "bordertype", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu04S", "bordertype", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu05S", "bordertype", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu06S", "bordertype", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu07S", "bordertype", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu08S", "bordertype", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu09S", "bordertype", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu10S", "bordertype", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu11S", "bordertype", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_2DepthMenu", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_TOP_SubMenu", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_TOP_Pre", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_RF_Xbtn", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu01", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu02", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu03", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu04", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu05", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu06", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu07", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu08", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_BOTTOM_Home", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_BOTTOM_Info", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_BOTTOM_Setup", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_BOTTOM_Cart", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_BOTTOM_Logout", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_LOGIN_Login", "bordertype", obj, ["normal", "disabled"]);
    this._addCss("Edit.edt_LOGIN_Login", "bordertype", obj, ["normal", "disabled"]);
    this._addCss("MaskEdit.msk_LOGIN_Login", "bordertype", obj, ["normal", "disabled"]);
    this._addCss("Button.btn_POP_XBtn", "bordertype", obj, ["normal"]);
    this._addCss("Calendar>#dropbutton", "bordertype", obj, ["normal"]);
    this._addCss("Calendar>#popupcalendar", "bordertype", obj, ["normal"]);
    this._addCss("Combo>#comboedit", "bordertype", obj, ["normal"]);
    this._addCss("Combo>#dropbutton", "bordertype", obj, ["normal"]);
    this._addCss("DatePickerControl", "bordertype", obj, ["normal"]);
    this._addCss("Grid>#controlcombo>#comboedit", "bordertype", obj, ["normal"]);
    this._addCss("Grid>#controlcombo>#dropbutton", "bordertype", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#dropbutton", "bordertype", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#popupcalendar", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_WF_SpinMinus", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_WF_SpinPlus", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_WF_MonthCalPreBtn", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_WF_MonthCalNextBtn", "bordertype", obj, ["normal"]);
    this._addCss("Button.btn_WF_TabTFOn", "bordertype", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_TabTFOff", "bordertype", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_TabMFOn", "bordertype", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_TabMFOff", "bordertype", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_More", "bordertype", obj, ["normal"]);
    this._addCss("MaskEdit.msk_WF_Spin", "bordertype", obj, ["normal"]);

    obj = new nexacro.Style_value("0");
    this._addCss("MainFrame", "statusbarheight", obj, ["normal"]);

    obj = new nexacro.Style_value("24");
    this._addCss("MainFrame", "titlebarheight", obj, ["normal"]);

    obj = new nexacro.Style_align("left top");
    this._addCss("ChildFrame", "align", obj, ["normal"]);
    this._addCss("TextArea", "align", obj, ["normal", "mouseover", "focused"]);

    obj = new nexacro.Style_background("","","","0","0","0","0","true");
    this._addCss("ChildFrame", "background", obj, ["normal"]);
    this._addCss("Static.sta_RF_WelcomeArea", "background", obj, ["normal"]);
    this._addCss("Static.sta_RF_WelcomeName", "background", obj, ["normal"]);
    this._addCss("CheckBox.chk_LOGIN_Login", "background", obj, ["normal"]);
    this._addCss("Calendar>#calendaredit", "background", obj, ["normal"]);
    this._addCss("CheckBox", "background", obj, ["normal", "pushed"]);
    this._addCss("Combo", "background", obj, ["normal", "focused", "mouseover"]);
    this._addCss("Div", "background", obj, ["normal"]);
    this._addCss("Grid", "background", obj, ["normal"]);
    this._addCss("Grid>#controlcombo", "background", obj, ["normal"]);
    this._addCss("Grid>#controlcheckbox", "background", obj, ["normal", "pushed"]);
    this._addCss("Grid>#controlcalendar>#calendaredit", "background", obj, ["normal"]);
    this._addCss("PopupDiv", "background", obj, ["normal"]);
    this._addCss("Radio", "background", obj, ["normal", "pushed"]);
    this._addCss(".CellGrd_WF_ColorRed", "background", obj, ["normal"]);
    this._addCss(".CellGrd_WF_ColorBlue", "background", obj, ["normal"]);
    this._addCss("Grid.grd_WF_MonthCal", "background", obj, ["normal"]);
    this._addCss("Grid.grd_WF_SumType>#body", "background", obj, ["normal"]);
    this._addCss("Static.sta_GUIDE_BlackText", "background", obj, ["normal"]);
    this._addCss("Static.sta_GUIDE_RedText", "background", obj, ["normal"]);
    this._addCss("Static.sta_GUIDE_BlackBoldText", "background", obj, ["normal"]);

    obj = new nexacro.Style_border("0","none","","");
    this._addCss("ChildFrame", "border", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu01", "border", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu02", "border", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu03", "border", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu04", "border", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu05", "border", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu06", "border", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu07", "border", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu08", "border", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu09", "border", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu10", "border", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu11", "border", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu01S", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu02S", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu03S", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu04S", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu05S", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu06S", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu07S", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu08S", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu09S", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu10S", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_Menu11S", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_MAIN_2DepthMenu", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_TOP_SubMenu", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_TOP_Pre", "border", obj, ["normal", "pushed"]);
    this._addCss("Static.sta_TOP_Bg", "border", obj, ["normal"]);
    this._addCss("Button.btn_RF_Xbtn", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_RF_Setting", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_RF_Menu01", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_RF_Menu02", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_RF_Menu03", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_RF_Menu04", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_RF_Menu05", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_RF_Menu06", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_RF_Menu07", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_RF_Menu08", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_BOTTOM_Home", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_BOTTOM_Info", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_BOTTOM_Setup", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_BOTTOM_Cart", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_BOTTOM_Logout", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_LOGIN_Login", "border", obj, ["normal", "disabled", "pushed"]);
    this._addCss("CheckBox.chk_LOGIN_Login", "border", obj, ["normal"]);
    this._addCss("Button.btn_POP_XBtn", "border", obj, ["normal", "pushed"]);
    this._addCss("TextArea.txt_POP_AltCfm", "border", obj, ["normal", "focused"]);
    this._addCss("Calendar>#calendaredit", "border", obj, ["normal"]);
    this._addCss("Calendar>#dropbutton", "border", obj, ["normal"]);
    this._addCss("Calendar>#popupcalendar>#prevbutton", "border", obj, ["normal"]);
    this._addCss("Calendar>#popupcalendar>#nextbutton", "border", obj, ["normal"]);
    this._addCss("CheckBox", "border", obj, ["normal", "pushed"]);
    this._addCss("Combo>#comboedit", "border", obj, ["normal"]);
    this._addCss("Combo>#dropbutton", "border", obj, ["normal"]);
    this._addCss("Div", "border", obj, ["normal"]);
    this._addCss("Grid>#controlcombo>#comboedit", "border", obj, ["normal"]);
    this._addCss("Grid>#controlcombo>#dropbutton", "border", obj, ["normal"]);
    this._addCss("Grid>#controlcheckbox", "border", obj, ["normal", "pushed"]);
    this._addCss("Grid>#controlcalendar>#calendaredit", "border", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#dropbutton", "border", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#popupcalendar>#prevbutton", "border", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#popupcalendar>#nextbutton", "border", obj, ["normal"]);
    this._addCss("PopupDiv", "border", obj, ["normal"]);
    this._addCss("Radio", "border", obj, ["normal", "pushed"]);
    this._addCss("Static", "border", obj, ["normal"]);
    this._addCss("VScrollBarControl", "border", obj, ["normal"]);
    this._addCss("VScrollBarControl>#trackbar", "border", obj, ["normal"]);
    this._addCss("HScrollBarControl", "border", obj, ["normal"]);
    this._addCss("HScrollBarControl>#trackbar", "border", obj, ["normal"]);
    this._addCss("Tab", "border", obj, ["selected", "focused"]);
    this._addCss("Button.btn_WF_MonthCalPreBtn", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_MonthCalNextBtn", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_TabTFOn", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_TabTFOff", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_EdtSearch", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_More", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_Top", "border", obj, ["normal", "pushed"]);
    this._addCss("Grid.grd_WF_MonthCal", "border", obj, ["normal"]);
    this._addCss("Grid.grd_WF_SubMenuList", "border", obj, ["normal"]);

    obj = new nexacro.Style_background("#ffffffff","theme://Image/btn_MAIN_Menu01.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu01", "background", obj, ["normal"]);

    obj = new nexacro.Style_border("1","solid","#f1f1f1ff","","1","solid","#f1f1f1ff","","1","solid","#f1f1f1ff","","1","solid","#f1f1f1ff","");
    this._addCss("Button.btn_MAIN_Menu01", "border", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu02", "border", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu03", "border", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu04", "border", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu05", "border", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu06", "border", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu07", "border", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu08", "border", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu09", "border", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu10", "border", obj, ["normal"]);
    this._addCss("Button.btn_MAIN_Menu11", "border", obj, ["normal"]);

    obj = new nexacro.Style_background("#f57f50ff","theme://Image/btn_MAIN_Menu01S.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu01", "background", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu01S", "background", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("#ffffffff","theme://Image/btn_MAIN_Menu02.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu02", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f57f50ff","theme://Image/btn_MAIN_Menu02S.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu02", "background", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu02S", "background", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("#ffffffff","theme://Image/btn_MAIN_Menu03.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu03", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f57f50ff","theme://Image/btn_MAIN_Menu03S.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu03", "background", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu03S", "background", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("#ffffffff","theme://Image/btn_MAIN_Menu04.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu04", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f57f50ff","theme://Image/btn_MAIN_Menu04S.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu04", "background", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu04S", "background", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("#ffffffff","theme://Image/btn_MAIN_Menu05.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu05", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f57f50ff","theme://Image/btn_MAIN_Menu05S.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu05", "background", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu05S", "background", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("#ffffffff","theme://Image/btn_MAIN_Menu06.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu06", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f57f50ff","theme://Image/btn_MAIN_Menu06S.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu06", "background", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu06S", "background", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("#ffffffff","theme://Image/btn_MAIN_Menu07.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu07", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f57f50ff","theme://Image/btn_MAIN_Menu07S.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu07", "background", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu07S", "background", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("#ffffffff","theme://Image/btn_MAIN_Menu08.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu08", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f57f50ff","theme://Image/btn_MAIN_Menu08S.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu08", "background", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu08S", "background", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("#ffffffff","theme://Image/btn_MAIN_Menu09.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu09", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f57f50ff","theme://Image/btn_MAIN_Menu09S.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu09", "background", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu09S", "background", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("#ffffffff","theme://Image/btn_MAIN_Menu10.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu10", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f57f50ff","theme://Image/btn_MAIN_Menu10S.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu10", "background", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu10S", "background", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("#ffffffff","theme://Image/btn_MAIN_Menu11.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu11", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f57f50ff","theme://Image/btn_MAIN_Menu11S.png","","0","0","50","50","true");
    this._addCss("Button.btn_MAIN_Menu11", "background", obj, ["pushed"]);
    this._addCss("Button.btn_MAIN_Menu11S", "background", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("#f8a685ff","theme://Image/btn_MAIN_2DepthMenu.png","","0","0","0","50","true");
    this._addCss("Button.btn_MAIN_2DepthMenu", "background", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 14 Droid Sans");
    this._addCss("Button.btn_MAIN_2DepthMenu", "font", obj, ["normal"]);
    this._addCss("Button.btn_WF_More", "font", obj, ["normal"]);

    obj = new nexacro.Style_color("#ffffff");
    this._addCss("Button.btn_MAIN_2DepthMenu", "color", obj, ["normal", "pushed"]);
    this._addCss("Static.sta_MAIN_WelcomeBg", "color", obj, ["normal"]);
    this._addCss("Static.sta_TOP_Bg", "color", obj, ["normal"]);
    this._addCss("Static.sta_RF_WelcomeArea", "color", obj, ["normal"]);
    this._addCss("Static.sta_POP_TitleBg", "color", obj, ["normal"]);
    this._addCss("Static.sta_POP_AltCfmTitleBg", "color", obj, ["normal"]);
    this._addCss("Grid>#controlbutton", "color", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_Function", "color", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_Search", "color", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_TabTFOn", "color", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_TabMFOn", "color", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_More", "color", obj, ["normal"]);
    this._addCss(".CellGrd_WF_LabelIndigo", "color", obj, ["normal"]);
    this._addCss("Static.sta_WF_PopCalTitle", "color", obj, ["normal"]);
    this._addCss("Static.sta_WF_MonthCalTitle", "color", obj, ["normal"]);

    obj = new nexacro.Style_align("left middle");
    this._addCss("Button.btn_MAIN_2DepthMenu", "align", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu01", "align", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu02", "align", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu03", "align", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu04", "align", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu05", "align", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu06", "align", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu07", "align", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu08", "align", obj, ["normal"]);
    this._addCss("CheckBox.chk_LOGIN_Login", "align", obj, ["normal"]);
    this._addCss("MaskEdit.msk_LOGIN_Login", "align", obj, ["normal", "disabled"]);
    this._addCss("Calendar", "align", obj, ["normal"]);
    this._addCss("Calendar>#calendaredit", "align", obj, ["normal"]);
    this._addCss("CheckBox", "align", obj, ["normal", "pushed"]);
    this._addCss("Combo", "align", obj, ["normal", "focused", "mouseover"]);
    this._addCss("Combo>#comboedit", "align", obj, ["normal"]);
    this._addCss("Combo>#combolist", "align", obj, ["normal"]);
    this._addCss("Edit", "align", obj, ["normal"]);
    this._addCss("Grid>#controledit", "align", obj, ["normal"]);
    this._addCss("Grid>#controlcombo", "align", obj, ["normal"]);
    this._addCss("Grid>#controlcombo>#comboedit", "align", obj, ["normal"]);
    this._addCss("Grid>#controlcheckbox", "align", obj, ["normal", "pushed"]);
    this._addCss("Grid>#controlcalendar", "align", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#calendaredit", "align", obj, ["normal"]);
    this._addCss("Radio", "align", obj, ["normal", "pushed"]);
    this._addCss("Static", "align", obj, ["normal"]);
    this._addCss("Button.btn_WF_Search", "align", obj, ["normal"]);
    this._addCss(".CellGrd_WF_LabelGray", "align", obj, ["normal"]);
    this._addCss(".CellGrd_WF_LabelIndigo", "align", obj, ["normal"]);

    obj = new nexacro.Style_padding("1 0 0 21");
    this._addCss("Button.btn_MAIN_2DepthMenu", "padding", obj, ["normal"]);

    obj = new nexacro.Style_background("#d8603aff","theme://Image/btn_MAIN_2DepthMenu.png","","0","0","0","50","true");
    this._addCss("Button.btn_MAIN_2DepthMenu", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("","theme://Image/div_MAIN_2DepthMenuBg.png","stretch","3","0","3","0","true");
    this._addCss("Div.div_MAIN_2DepthMenuBg", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#47475aff","","","0","0","0","0","true");
    this._addCss("Static.sta_MAIN_WelcomeBg", "background", obj, ["normal"]);

    obj = new nexacro.Style_border("2","solid","#3a3a43ff","","0","none","","","0","none","","","0","none","","");
    this._addCss("Static.sta_MAIN_WelcomeBg", "border", obj, ["normal"]);

    obj = new nexacro.Style_font("antialias 19 Droid Sans");
    this._addCss("Static.sta_MAIN_WelcomeBg", "font", obj, ["normal"]);
    this._addCss("Edit.edt_LOGIN_Login", "font", obj, ["normal", "disabled"]);
    this._addCss("MaskEdit.msk_LOGIN_Login", "font", obj, ["normal", "disabled"]);

    obj = new nexacro.Style_padding("0 0 0 20");
    this._addCss("Static.sta_MAIN_WelcomeBg", "padding", obj, ["normal"]);

    obj = new nexacro.Style_background("","theme://Image/sta_MAIN_BgImg.png","","0","0","50","50","true");
    this._addCss("Static.sta_MAIN_BgImg", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("","theme://Image/btn_TOP_SubMenu.png","","0","0","50","50","true");
    this._addCss("Button.btn_TOP_SubMenu", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("","theme://Image/btn_TOP_SubMenuP.png","","0","0","50","50","true");
    this._addCss("Button.btn_TOP_SubMenu", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("","theme://Image/btn_TOP_Pre.png","","0","0","50","50","true");
    this._addCss("Button.btn_TOP_Pre", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("","theme://Image/btn_TOP_PreP.png","","0","0","50","50","true");
    this._addCss("Button.btn_TOP_Pre", "background", obj, ["pushed"]);

    obj = new nexacro.Style_align("center middle.");
    this._addCss("Static.sta_TOP_Bg", "align", obj, ["normal"]);

    obj = new nexacro.Style_background("#f57f50ff","","","0","0","0","0","true");
    this._addCss("Static.sta_TOP_Bg", "background", obj, ["normal"]);
    this._addCss("Static.sta_RF_BtnBg", "background", obj, ["normal"]);
    this._addCss("Static.sta_LOGIN_Bg02", "background", obj, ["normal"]);
    this._addCss("Static.sta_POP_TitleBg", "background", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 25 Droid Sans");
    this._addCss("Static.sta_TOP_Bg", "font", obj, ["normal"]);

    obj = new nexacro.Style_background("#4a4a5dff","theme://Image/btn_RF_Xbtn.png","","0","0","50","50","true");
    this._addCss("Button.btn_RF_Xbtn", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#35354dff","theme://Image/btn_RF_Xbtn.png","","0","0","50","50","true");
    this._addCss("Button.btn_RF_Xbtn", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#4a4a5dff","theme://Image/btn_RF_Setting.png","","0","0","50","50","true");
    this._addCss("Button.btn_RF_Setting", "background", obj, ["normal"]);

    obj = new nexacro.Style_bordertype("round","8","8","true","true","true","true");
    this._addCss("Button.btn_RF_Setting", "bordertype", obj, ["normal"]);

    obj = new nexacro.Style_background("#35354dff","theme://Image/btn_RF_Setting.png","","0","0","50","50","true");
    this._addCss("Button.btn_RF_Setting", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#f8f8f8ff","theme://Image/btn_RF_Menu01.png","","0","0","0","50","true");
    this._addCss("Button.btn_RF_Menu01", "background", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 19 Droid Sans");
    this._addCss("Button.btn_RF_Menu01", "font", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu02", "font", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu03", "font", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu04", "font", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu05", "font", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu06", "font", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu07", "font", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu08", "font", obj, ["normal"]);
    this._addCss("Static.sta_RF_WelcomeArea", "font", obj, ["normal"]);
    this._addCss("Static.sta_RF_WelcomeName", "font", obj, ["normal"]);
    this._addCss("Button", "font", obj, ["normal"]);
    this._addCss("Button.btn_WF_TabTFOn", "font", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_TabTFOff", "font", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_TabMFOn", "font", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_TabMFOff", "font", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_color("#48484f");
    this._addCss("Button.btn_RF_Menu01", "color", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_RF_Menu02", "color", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_RF_Menu03", "color", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_RF_Menu04", "color", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_RF_Menu05", "color", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_RF_Menu06", "color", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_RF_Menu07", "color", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_RF_Menu08", "color", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_padding("2 0 0 99");
    this._addCss("Button.btn_RF_Menu01", "padding", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu02", "padding", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu03", "padding", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu04", "padding", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu05", "padding", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu06", "padding", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu07", "padding", obj, ["normal"]);
    this._addCss("Button.btn_RF_Menu08", "padding", obj, ["normal"]);

    obj = new nexacro.Style_background("#e7e7e7ff","theme://Image/btn_RF_Menu01.png","","0","0","0","50","true");
    this._addCss("Button.btn_RF_Menu01", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#f8f8f8ff","theme://Image/btn_RF_Menu02.png","","0","0","0","50","true");
    this._addCss("Button.btn_RF_Menu02", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#e7e7e7ff","theme://Image/btn_RF_Menu02.png","","0","0","0","50","true");
    this._addCss("Button.btn_RF_Menu02", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#f8f8f8ff","theme://Image/btn_RF_Menu03.png","","0","0","0","50","true");
    this._addCss("Button.btn_RF_Menu03", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#e7e7e7ff","theme://Image/btn_RF_Menu03.png","","0","0","0","50","true");
    this._addCss("Button.btn_RF_Menu03", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#f8f8f8ff","theme://Image/btn_RF_Menu04.png","","0","0","0","50","true");
    this._addCss("Button.btn_RF_Menu04", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#e7e7e7ff","theme://Image/btn_RF_Menu04.png","","0","0","0","50","true");
    this._addCss("Button.btn_RF_Menu04", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#f8f8f8ff","theme://Image/btn_RF_Menu05.png","","0","0","0","50","true");
    this._addCss("Button.btn_RF_Menu05", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#e7e7e7ff","theme://Image/btn_RF_Menu05.png","","0","0","0","50","true");
    this._addCss("Button.btn_RF_Menu05", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#f8f8f8ff","theme://Image/btn_RF_Menu06.png","","0","0","0","50","true");
    this._addCss("Button.btn_RF_Menu06", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#e7e7e7ff","theme://Image/btn_RF_Menu06.png","","0","0","0","50","true");
    this._addCss("Button.btn_RF_Menu06", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#f8f8f8ff","theme://Image/btn_RF_Menu07.png","","0","0","0","50","true");
    this._addCss("Button.btn_RF_Menu07", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#e7e7e7ff","theme://Image/btn_RF_Menu07.png","","0","0","0","50","true");
    this._addCss("Button.btn_RF_Menu07", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#f8f8f8ff","theme://Image/btn_RF_Menu08.png","","0","0","0","50","true");
    this._addCss("Button.btn_RF_Menu08", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#e7e7e7ff","theme://Image/btn_RF_Menu08.png","","0","0","0","50","true");
    this._addCss("Button.btn_RF_Menu08", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#656574ff","theme://Image/sta_RF_Welcome.png","","0","0","0","100","true");
    this._addCss("Static.sta_RF_WelcomeBg", "background", obj, ["normal"]);

    obj = new nexacro.Style_color("#f3e584");
    this._addCss("Static.sta_RF_WelcomeName", "color", obj, ["normal"]);

    obj = new nexacro.Style_background("#f8f8f8ff","","","0","0","0","0","true");
    this._addCss("Static.sta_RF_BtnBg2", "background", obj, ["normal"]);
    this._addCss("Button", "background", obj, ["normal"]);
    this._addCss("Button.btn_WF_PageNum", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#656574ff","theme://Image/btn_BOTTOM_Home.png","","0","0","50","50","true");
    this._addCss("Button.btn_BOTTOM_Home", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#47475aff","theme://Image/btn_BOTTOM_HomeP.png","","0","0","50","50","true");
    this._addCss("Button.btn_BOTTOM_Home", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#656574ff","theme://Image/btn_BOTTOM_Info.png","","0","0","50","50","true");
    this._addCss("Button.btn_BOTTOM_Info", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#47475aff","theme://Image/btn_BOTTOM_InfoP.png","","0","0","50","50","true");
    this._addCss("Button.btn_BOTTOM_Info", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#656574ff","theme://Image/btn_BOTTOM_Setup.png","","0","0","50","50","true");
    this._addCss("Button.btn_BOTTOM_Setup", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#47475aff","theme://Image/btn_BOTTOM_SetupP.png","","0","0","50","50","true");
    this._addCss("Button.btn_BOTTOM_Setup", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#656574ff","theme://Image/btn_BOTTOM_Cart.png","","0","0","50","50","true");
    this._addCss("Button.btn_BOTTOM_Cart", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#47475aff","theme://Image/btn_BOTTOM_CartP.png","","0","0","50","50","true");
    this._addCss("Button.btn_BOTTOM_Cart", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#656574ff","theme://Image/btn_BOTTOM_Logout.png","","0","0","50","50","true");
    this._addCss("Button.btn_BOTTOM_Logout", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#47475aff","theme://Image/btn_BOTTOM_LogoutP.png","","0","0","50","50","true");
    this._addCss("Button.btn_BOTTOM_Logout", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#47475aff","theme://Image/btn_LOGIN_Login.png","","0","0","50","50","true");
    this._addCss("Button.btn_LOGIN_Login", "background", obj, ["normal", "disabled"]);

    obj = new nexacro.Style_background("#35354dff","theme://Image/btn_LOGIN_Login.png","","0","0","50","50","true");
    this._addCss("Button.btn_LOGIN_Login", "background", obj, ["pushed"]);

    obj = new nexacro.Style_font("bold antialias 17 Droid Sans");
    this._addCss("CheckBox.chk_LOGIN_Login", "font", obj, ["normal"]);
    this._addCss("Calendar", "font", obj, ["normal"]);
    this._addCss("CheckBox", "font", obj, ["normal", "pushed"]);
    this._addCss("Combo", "font", obj, ["normal", "focused", "mouseover"]);
    this._addCss("Edit", "font", obj, ["normal"]);
    this._addCss("Grid", "font", obj, ["normal"]);
    this._addCss("Grid>#controledit", "font", obj, ["normal"]);
    this._addCss("Grid>#controlmaskedit", "font", obj, ["normal"]);
    this._addCss("Grid>#controlcombo", "font", obj, ["normal"]);
    this._addCss("Grid>#controlcheckbox", "font", obj, ["normal", "pushed"]);
    this._addCss("Grid>#controlcalendar", "font", obj, ["normal"]);
    this._addCss("ImageViewer", "font", obj, ["normal"]);
    this._addCss("MaskEdit", "font", obj, ["normal"]);
    this._addCss("Radio", "font", obj, ["normal", "pushed"]);
    this._addCss("Static", "font", obj, ["normal"]);
    this._addCss("TextArea", "font", obj, ["normal", "mouseover", "focused"]);
    this._addCss("Grid.grd_WF_SumType", "font", obj, ["normal"]);
    this._addCss("MaskEdit.msk_WF_Spin", "font", obj, ["normal"]);
    this._addCss("Static.sta_WF_Label02", "font", obj, ["normal"]);

    obj = new nexacro.Style_color("#3c3c3c");
    this._addCss("CheckBox.chk_LOGIN_Login", "color", obj, ["normal"]);

    obj = new nexacro.Style_background("#ffffffff","","","0","0","0","0","true");
    this._addCss("CheckBox.chk_LOGIN_Login", "buttonbackground", obj, ["normal"]);
    this._addCss("CheckBox", "buttonbackground", obj, ["normal", "pushed"]);
    this._addCss("Grid>#controlcheckbox", "buttonbackground", obj, ["normal", "pushed"]);
    this._addCss("Radio", "buttonbackground", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_value("center middle");
    this._addCss("CheckBox.chk_LOGIN_Login", "buttonalign", obj, ["normal"]);
    this._addCss("Grid>#controlcheckbox", "buttonalign", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_value("1 solid #797979");
    this._addCss("CheckBox.chk_LOGIN_Login", "buttonborder", obj, ["normal"]);

    obj = new nexacro.Style_bordertype("round","3","3","true","true","true","true");
    this._addCss("CheckBox.chk_LOGIN_Login", "buttonbordertype", obj, ["normal"]);

    obj = new nexacro.Style_value("25");
    this._addCss("CheckBox.chk_LOGIN_Login", "buttonsize", obj, ["normal"]);
    this._addCss("CheckBox", "buttonsize", obj, ["normal", "pushed"]);
    this._addCss("Grid>#controlcheckbox", "buttonsize", obj, ["normal", "pushed"]);
    this._addCss("Radio", "buttonsize", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_padding("2 10 0 10");
    this._addCss("CheckBox.chk_LOGIN_Login", "textpadding", obj, ["normal"]);
    this._addCss("CheckBox", "textpadding", obj, ["normal", "pushed"]);
    this._addCss("Grid>#controlcheckbox", "textpadding", obj, ["normal", "pushed"]);
    this._addCss("Radio", "textpadding", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_value("URL('theme://Image/chk_LOGIN_BtnImg.png')");
    this._addCss("CheckBox.chk_LOGIN_Login", "buttonimage", obj, ["normal"]);

    obj = new nexacro.Style_value("40");
    this._addCss("CheckBox.chk_LOGIN_Login", "opacity", obj, ["disabled"]);
    this._addCss("Button", "opacity", obj, ["disabled"]);
    this._addCss("Calendar", "opacity", obj, ["disabled"]);
    this._addCss("Div", "opacity", obj, ["disabled"]);
    this._addCss("PopupDiv", "opacity", obj, ["disabled"]);
    this._addCss("Tab", "opacity", obj, ["disabled"]);

    obj = new nexacro.Style_border("1","solid","#9a9a9aff","");
    this._addCss("Edit.edt_LOGIN_Login", "border", obj, ["normal", "disabled"]);
    this._addCss("MaskEdit.msk_LOGIN_Login", "border", obj, ["normal", "disabled"]);
    this._addCss("Button", "border", obj, ["normal"]);
    this._addCss("Calendar", "border", obj, ["normal"]);
    this._addCss("Combo", "border", obj, ["normal", "focused", "mouseover"]);
    this._addCss("Combo>#combolist", "border", obj, ["normal"]);
    this._addCss("Edit", "border", obj, ["normal"]);
    this._addCss("Grid>#controledit", "border", obj, ["normal"]);
    this._addCss("Grid>#controlmaskedit", "border", obj, ["normal"]);
    this._addCss("Grid>#controlcombo", "border", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar", "border", obj, ["normal"]);
    this._addCss("ImageViewer", "border", obj, ["normal"]);
    this._addCss("MaskEdit", "border", obj, ["normal"]);
    this._addCss("TextArea", "border", obj, ["normal", "mouseover", "focused"]);
    this._addCss("Button.btn_WF_SpinMinus", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_SpinPlus", "border", obj, ["normal", "pushed"]);
    this._addCss("Static.sta_WF_PopCalTitle", "border", obj, ["normal"]);

    obj = new nexacro.Style_color("#555555");
    this._addCss("Edit.edt_LOGIN_Login", "color", obj, ["normal", "disabled"]);
    this._addCss("MaskEdit.msk_LOGIN_Login", "color", obj, ["normal", "disabled"]);
    this._addCss("Button", "color", obj, ["normal"]);
    this._addCss("Calendar", "color", obj, ["normal"]);
    this._addCss("CheckBox", "color", obj, ["normal", "pushed"]);
    this._addCss("Combo", "color", obj, ["normal", "focused", "mouseover"]);
    this._addCss("DatePickerControl", "color", obj, ["normal"]);
    this._addCss("Div", "color", obj, ["normal"]);
    this._addCss("Edit", "color", obj, ["normal"]);
    this._addCss("Grid", "color", obj, ["normal"]);
    this._addCss("Grid>#controledit", "color", obj, ["normal"]);
    this._addCss("Grid>#controlmaskedit", "color", obj, ["normal"]);
    this._addCss("Grid>#controlcombo", "color", obj, ["normal"]);
    this._addCss("Grid>#controlcheckbox", "color", obj, ["normal", "pushed"]);
    this._addCss("Grid>#controlcalendar", "color", obj, ["normal"]);
    this._addCss("ImageViewer", "color", obj, ["normal"]);
    this._addCss("MaskEdit", "color", obj, ["normal"]);
    this._addCss("PopupDiv", "color", obj, ["normal"]);
    this._addCss("Radio", "color", obj, ["normal", "pushed"]);
    this._addCss("Static", "color", obj, ["normal"]);
    this._addCss("TextArea", "color", obj, ["normal", "mouseover", "focused"]);
    this._addCss("Button.btn_WF_TabTFOff", "color", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_TabMFOff", "color", obj, ["normal", "pushed"]);
    this._addCss("Grid.grd_WF_MonthCal", "color", obj, ["normal"]);
    this._addCss("Grid.grd_WF_SumType", "color", obj, ["normal"]);
    this._addCss("MaskEdit.msk_WF_Spin", "color", obj, ["normal"]);
    this._addCss("Static.sta_WF_WebzineText", "color", obj, ["normal"]);

    obj = new nexacro.Style_padding("0 10 0 21");
    this._addCss("Edit.edt_LOGIN_Login", "padding", obj, ["normal", "disabled"]);
    this._addCss("MaskEdit.msk_LOGIN_Login", "padding", obj, ["normal", "disabled"]);

    obj = new nexacro.Style_background("#fdfae9ff","","","0","0","0","0","true");
    this._addCss("Static.sta_LOGIN_Bg01", "background", obj, ["normal"]);
    this._addCss("Grid.grd_WF_SumType", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("","theme://Image/sta_LOGIN_BgImg.png","","0","0","50","50","true");
    this._addCss("Static.sta_LOGIN_BgImg", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("","theme://Image/sta_LOGIN_Copyright.png","","0","0","50","50","true");
    this._addCss("Static.sta_LOGIN_Copyright", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("","theme://Image/sta_LOGIN_Login.png","","0","0","0","0","true");
    this._addCss("Static.sta_LOGIN_Login", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#47475aff","theme://Image/btn_POP_XBtn.png","","0","0","50","50","true");
    this._addCss("Button.btn_POP_XBtn", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#47475aff","theme://Image/btn_POP_XBtnP.png","","0","0","50","50","true");
    this._addCss("Button.btn_POP_XBtn", "background", obj, ["pushed"]);

    obj = new nexacro.Style_font("bold antialias 27 Droid Sans");
    this._addCss("Static.sta_POP_TitleBg", "font", obj, ["normal"]);
    this._addCss("Static.sta_POP_AltCfmTitleBg", "font", obj, ["normal"]);
    this._addCss("DatePickerControl", "font", obj, ["normal"]);
    this._addCss("Grid.grd_WF_MonthCal", "font", obj, ["normal"]);

    obj = new nexacro.Style_padding("0 30 0 0");
    this._addCss("Static.sta_POP_TitleBg", "padding", obj, ["normal"]);

    obj = new nexacro.Style_background("#675eb1ff","","","0","0","0","0","true");
    this._addCss("Static.sta_POP_AltCfmTitleBg", "background", obj, ["normal"]);

    obj = new nexacro.Style_padding("10 10 10 10");
    this._addCss("TextArea.txt_POP_AltCfm", "padding", obj, ["normal", "focused"]);
    this._addCss("TextArea", "padding", obj, ["normal", "mouseover", "focused"]);

    obj = new nexacro.Style_bordertype("round","3","3","true","true","true","true");
    this._addCss("Button", "bordertype", obj, ["normal"]);
    this._addCss("Calendar", "bordertype", obj, ["normal"]);
    this._addCss("Combo", "bordertype", obj, ["normal", "focused", "mouseover"]);
    this._addCss("Combo>#combolist", "bordertype", obj, ["normal"]);
    this._addCss("Edit", "bordertype", obj, ["normal"]);
    this._addCss("Grid>#controledit", "bordertype", obj, ["normal"]);
    this._addCss("Grid>#controlmaskedit", "bordertype", obj, ["normal"]);
    this._addCss("Grid>#controlcombo", "bordertype", obj, ["normal"]);
    this._addCss("Grid>#controlbutton", "bordertype", obj, ["normal", "pushed"]);
    this._addCss("Grid>#controlcalendar", "bordertype", obj, ["normal"]);
    this._addCss("MaskEdit", "bordertype", obj, ["normal"]);
    this._addCss("TextArea", "bordertype", obj, ["normal", "mouseover", "focused"]);

    obj = new nexacro.Style_value("hand");
    this._addCss("Button", "cursor", obj, ["normal"]);
    this._addCss("Calendar>#popupcalendar>#prevbutton", "cursor", obj, ["normal"]);
    this._addCss("Calendar>#popupcalendar>#nextbutton", "cursor", obj, ["normal"]);
    this._addCss("CheckBox", "cursor", obj, ["normal", "pushed"]);
    this._addCss("Grid>#controlcheckbox", "cursor", obj, ["normal", "pushed"]);
    this._addCss("Grid>#controlcalendar>#popupcalendar>#prevbutton", "cursor", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#popupcalendar>#nextbutton", "cursor", obj, ["normal"]);

    obj = new nexacro.Style_padding("");
    this._addCss("Button", "padding", obj, ["normal"]);

    obj = new nexacro.Style_shadow("0 0");
    this._addCss("Button", "shadow", obj, ["normal"]);

    obj = new nexacro.Style_background("#f0f0f0ff","","","0","0","0","0","true");
    this._addCss("Button", "background", obj, ["pushed"]);
    this._addCss("Button.btn_WF_PageNum", "background", obj, ["pushed"]);

    obj = new nexacro.Style_border("1","solid","#f57f50ff","");
    this._addCss("Button", "border", obj, ["pushed"]);

    obj = new nexacro.Style_color("#f57f50");
    this._addCss("Button", "color", obj, ["pushed"]);

    obj = new nexacro.Style_value("45");
    this._addCss("Calendar", "buttonsize", obj, ["normal"]);
    this._addCss("Combo", "buttonsize", obj, ["normal", "focused", "mouseover"]);
    this._addCss("Grid>#controlcombo", "buttonsize", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar", "buttonsize", obj, ["normal"]);

    obj = new nexacro.Style_background("#ffffffff","","","0","0","0","0","true");
    this._addCss("Calendar", "daybackground", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar", "daybackground", obj, ["normal"]);

    obj = new nexacro.Style_border("0","none","","");
    this._addCss("Calendar", "dayborder", obj, ["normal", "mouseover", "selected", "focused"]);
    this._addCss("Grid>#controlcalendar", "dayborder", obj, ["normal", "selected", "focused"]);

    obj = new nexacro.Style_color("#555555");
    this._addCss("Calendar", "daycolor", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar", "daycolor", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 27 Droid Sans");
    this._addCss("Calendar", "dayfont", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar", "dayfont", obj, ["normal"]);

    obj = new nexacro.Style_value("71 71");
    this._addCss("Calendar", "daysize", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar", "daysize", obj, ["normal"]);

    obj = new nexacro.Style_background("#ffffffff","","","0","0","0","0","true");
    this._addCss("Calendar", "popupbackground", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar", "popupbackground", obj, ["normal"]);

    obj = new nexacro.Style_border("1","solid","#c0c0c0ff","");
    this._addCss("Calendar", "popupborder", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar", "popupborder", obj, ["normal"]);

    obj = new nexacro.Style_value("500 580");
    this._addCss("Calendar", "popupsize", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar", "popupsize", obj, ["normal"]);

    obj = new nexacro.Style_background("#f57f50ff","","","0","0","0","0","true");
    this._addCss("Calendar", "daybackground", obj, ["mouseover", "selected", "focused"]);
    this._addCss("Grid>#controlcalendar", "daybackground", obj, ["selected", "focused"]);

    obj = new nexacro.Style_color("#ffffff");
    this._addCss("Calendar", "daycolor", obj, ["mouseover", "selected", "focused"]);
    this._addCss("Grid>#controlcalendar", "daycolor", obj, ["selected", "focused"]);

    obj = new nexacro.Style_padding("0 0 0 10");
    this._addCss("Calendar>#calendaredit", "padding", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#calendaredit", "padding", obj, ["normal"]);

    obj = new nexacro.Style_margin("0 -1 0 0");
    this._addCss("Calendar>#calendaredit", "margin", obj, ["normal"]);
    this._addCss("Combo>#comboedit", "margin", obj, ["normal"]);
    this._addCss("Grid>#controlcombo>#comboedit", "margin", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#calendaredit", "margin", obj, ["normal"]);

    obj = new nexacro.Style_bordertype("normal","0","0","true","true","true","true");
    this._addCss("Calendar>#calendaredit", "bordertype", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#calendaredit", "bordertype", obj, ["normal"]);
    this._addCss("Tab", "bordertype", obj, ["selected", "focused"]);

    obj = new nexacro.Style_value("transparent");
    this._addCss("Calendar>#calendaredit", "selectbackground", obj, ["normal"]);
    this._addCss("Combo>#comboedit", "selectbackground", obj, ["normal"]);
    this._addCss("Grid>#controledit", "selectbackground", obj, ["normal"]);
    this._addCss("Grid>#controlmaskedit", "selectbackground", obj, ["normal"]);
    this._addCss("Grid>#controlcombo>#comboedit", "selectbackground", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#calendaredit", "selectbackground", obj, ["normal"]);
    this._addCss("Grid.grd_WF_MonthCal>#body", "selectbackground", obj, ["normal"]);
    this._addCss("Grid.grd_WF_SumType>#body", "selectbackground", obj, ["normal"]);

    obj = new nexacro.Style_font("#555555");
    this._addCss("Calendar>#calendaredit", "selectfont", obj, ["normal"]);
    this._addCss("Combo>#comboedit", "selectfont", obj, ["normal"]);
    this._addCss("Edit", "selectfont", obj, ["normal"]);
    this._addCss("Grid>#controledit", "selectfont", obj, ["normal"]);
    this._addCss("Grid>#controlmaskedit", "selectfont", obj, ["normal"]);
    this._addCss("Grid>#controlcombo>#comboedit", "selectfont", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#calendaredit", "selectfont", obj, ["normal"]);
    this._addCss("MaskEdit", "selectfont", obj, ["normal"]);
    this._addCss("TextArea", "selectfont", obj, ["normal", "mouseover", "focused"]);

    obj = new nexacro.Style_value("#f57f50");
    this._addCss("Calendar>#calendaredit", "selectbackground", obj, ["selected"]);
    this._addCss("Combo>#comboedit", "selectbackground", obj, ["selected"]);
    this._addCss("Grid>#controledit", "selectbackground", obj, ["selected"]);
    this._addCss("Grid>#controlmaskedit", "selectbackground", obj, ["selected"]);
    this._addCss("Grid>#controlcombo>#comboedit", "selectbackground", obj, ["selected"]);
    this._addCss("Grid>#controlcalendar>#calendaredit", "selectbackground", obj, ["selected"]);

    obj = new nexacro.Style_font("#ffffff");
    this._addCss("Calendar>#calendaredit", "selectfont", obj, ["selected"]);
    this._addCss("Combo>#comboedit", "selectfont", obj, ["selected"]);
    this._addCss("Edit", "selectfont", obj, ["selected"]);
    this._addCss("Grid>#controledit", "selectfont", obj, ["selected"]);
    this._addCss("Grid>#controlmaskedit", "selectfont", obj, ["selected"]);
    this._addCss("Grid>#controlcombo>#comboedit", "selectfont", obj, ["selected"]);
    this._addCss("Grid>#controlcalendar>#calendaredit", "selectfont", obj, ["selected"]);
    this._addCss("MaskEdit", "selectfont", obj, ["selected"]);
    this._addCss("TextArea", "selectfont", obj, ["selected"]);

    obj = new nexacro.Style_background("","theme://Image/cal_WF_DropBtn.png","","0","0","50","50","true");
    this._addCss("Calendar>#dropbutton", "background", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#dropbutton", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("","theme://Image/cal_WF_DropBtnP.png","","0","0","50","50","true");
    this._addCss("Calendar>#dropbutton", "background", obj, ["pushed", "selected", "focused"]);
    this._addCss("Grid>#controlcalendar>#dropbutton", "background", obj, ["pushed", "selected", "focused"]);

    obj = new nexacro.Style_value("83");
    this._addCss("Calendar>#popupcalendar", "headerheight", obj, ["normal"]);
    this._addCss("DatePickerControl", "headerheight", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#popupcalendar", "headerheight", obj, ["normal"]);

    obj = new nexacro.Style_color("#ffffff");
    this._addCss("Calendar>#popupcalendar", "headercolor", obj, ["normal"]);
    this._addCss("DatePickerControl", "headercolor", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#popupcalendar", "headercolor", obj, ["normal"]);

    obj = new nexacro.Style_background("#656574ff","","","0","0","0","0","true");
    this._addCss("Calendar>#popupcalendar", "headerbackground", obj, ["normal"]);
    this._addCss("DatePickerControl", "headerbackground", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#popupcalendar", "headerbackground", obj, ["normal"]);

    obj = new nexacro.Style_border("0","none","","");
    this._addCss("Calendar>#popupcalendar", "headerborder", obj, ["normal"]);
    this._addCss("DatePickerControl", "headerborder", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#popupcalendar", "headerborder", obj, ["normal"]);

    obj = new nexacro.Style_bordertype("normal","0","0","true","true","true","true");
    this._addCss("Calendar>#popupcalendar", "headerbordertype", obj, ["normal"]);
    this._addCss("DatePickerControl", "headerbordertype", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#popupcalendar", "headerbordertype", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 34 Droid Sans");
    this._addCss("Calendar>#popupcalendar", "headerfont", obj, ["normal"]);
    this._addCss("DatePickerControl", "headerfont", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#popupcalendar", "headerfont", obj, ["normal"]);

    obj = new nexacro.Style_background("","theme://Image/cal_WF_PreBtn.png","","0","0","50","50","true");
    this._addCss("Calendar>#popupcalendar>#prevbutton", "background", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#popupcalendar>#prevbutton", "background", obj, ["normal"]);
    this._addCss("Button.btn_WF_MonthCalPreBtn", "background", obj, ["normal"]);

    obj = new nexacro.Style_value("50");
    this._addCss("Calendar>#popupcalendar>#prevbutton", "opacity", obj, ["pushed"]);
    this._addCss("Calendar>#popupcalendar>#nextbutton", "opacity", obj, ["pushed"]);
    this._addCss("Grid>#controlcalendar>#popupcalendar>#prevbutton", "opacity", obj, ["pushed"]);
    this._addCss("Grid>#controlcalendar>#popupcalendar>#nextbutton", "opacity", obj, ["pushed"]);

    obj = new nexacro.Style_background("","theme://Image/cal_WF_NextBtn.png","","0","0","50","50","true");
    this._addCss("Calendar>#popupcalendar>#nextbutton", "background", obj, ["normal"]);
    this._addCss("Grid>#controlcalendar>#popupcalendar>#nextbutton", "background", obj, ["normal"]);
    this._addCss("Button.btn_WF_MonthCalNextBtn", "background", obj, ["normal"]);

    obj = new nexacro.Style_padding("0 0 0 0");
    this._addCss("CheckBox", "padding", obj, ["normal", "pushed"]);
    this._addCss("Combo", "padding", obj, ["normal", "focused", "mouseover"]);
    this._addCss("Grid>#controlcombo", "padding", obj, ["normal"]);
    this._addCss("Grid>#controlcheckbox", "padding", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_value("center middle");
    this._addCss("CheckBox", "buttonalign", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_value("1 solid #9a9a9a");
    this._addCss("CheckBox", "buttonborder", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_bordertype("round","2","2","true","true","true","true");
    this._addCss("CheckBox", "buttonbordertype", obj, ["normal", "pushed"]);
    this._addCss("Grid>#controlcheckbox", "buttonbordertype", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_value("URL('theme://Image/chk_WF_BtnImg.png')");
    this._addCss("CheckBox", "buttonimage", obj, ["normal", "pushed"]);
    this._addCss("Grid>#controlcheckbox", "buttonimage", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_value("54");
    this._addCss("CheckBox", "opacity", obj, ["disabled"]);
    this._addCss("Combo", "opacity", obj, ["disabled"]);
    this._addCss("Edit", "opacity", obj, ["disabled"]);
    this._addCss("ImageViewer", "opacity", obj, ["disabled"]);
    this._addCss("MaskEdit", "opacity", obj, ["disabled"]);
    this._addCss("Radio", "opacity", obj, ["disabled"]);
    this._addCss("Static", "opacity", obj, ["disabled"]);
    this._addCss("TextArea", "opacity", obj, ["disabled"]);

    obj = new nexacro.Style_value("47");
    this._addCss("Combo", "itemheight", obj, ["normal", "focused", "mouseover"]);
    this._addCss("Grid>#controlcombo", "itemheight", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 17 Droid Sans");
    this._addCss("Combo", "itemfont", obj, ["normal", "focused", "mouseover"]);
    this._addCss("Grid>#controlcombo", "itemfont", obj, ["normal"]);

    obj = new nexacro.Style_border("0","none","","");
    this._addCss("Combo", "itemborder", obj, ["normal", "focused", "mouseover"]);
    this._addCss("Grid>#controlcombo", "itemborder", obj, ["normal"]);

    obj = new nexacro.Style_padding("0 10 0 10");
    this._addCss("Combo", "itempadding", obj, ["normal", "focused", "mouseover"]);
    this._addCss("Grid>#controlcombo", "itempadding", obj, ["normal"]);

    obj = new nexacro.Style_background("#f57f50ff","","","0","0","0","0","true");
    this._addCss("Combo", "itembackground", obj, ["selected"]);
    this._addCss("Grid>#controlcombo", "itembackground", obj, ["selected"]);

    obj = new nexacro.Style_color("#ffffff");
    this._addCss("Combo", "itemcolor", obj, ["selected"]);
    this._addCss("Grid>#controlcombo", "itemcolor", obj, ["selected"]);

    obj = new nexacro.Style_padding("0 5 0 10");
    this._addCss("Combo>#comboedit", "padding", obj, ["normal"]);
    this._addCss("Edit", "padding", obj, ["normal"]);
    this._addCss("Grid>#controledit", "padding", obj, ["normal"]);
    this._addCss("Grid>#controlcombo>#comboedit", "padding", obj, ["normal"]);
    this._addCss(".CellGrd_WF_LabelGray", "padding", obj, ["normal"]);
    this._addCss(".CellGrd_WF_LabelIndigo", "padding", obj, ["normal"]);

    obj = new nexacro.Style_background("#ffffffff","theme://Image/cmb_WF_DropBtn.png","","0","0","50","50","true");
    this._addCss("Combo>#dropbutton", "background", obj, ["normal"]);
    this._addCss("Grid>#controlcombo>#dropbutton", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#ffffffff","theme://Image/cmb_WF_DropBtnP.png","","0","0","50","50","true");
    this._addCss("Combo>#dropbutton", "background", obj, ["pushed", "selected", "focused"]);
    this._addCss("Grid>#controlcombo>#dropbutton", "background", obj, ["pushed", "selected", "focused"]);

    obj = new nexacro.Style_font("antialias bold 17 Droid Sans");
    this._addCss("Combo>#combolist", "font", obj, ["normal"]);

    obj = new nexacro.Style_border("0","none","","");
    this._addCss("DatePickerControl", "bodyborder", obj, ["normal"]);

    obj = new nexacro.Style_padding("83 0 0 0");
    this._addCss("DatePickerControl", "ncpadding", obj, ["normal"]);

    obj = new nexacro.Style_value("yyyy.MM");
    this._addCss("DatePickerControl", "headerformat", obj, ["normal"]);

    obj = new nexacro.Style_value("일 월 화 수 목 금 토");
    this._addCss("DatePickerControl", "weekformat", obj, ["normal"]);

    obj = new nexacro.Style_background("#ffffffff","","","0","0","0","0","true");
    this._addCss("DatePickerControl", "bodybackground", obj, ["normal"]);

    obj = new nexacro.Style_bordertype("normal","0","0","true","true","true","true");
    this._addCss("DatePickerControl", "bodybordertype", obj, ["normal"]);

    obj = new nexacro.Style_color("#555555");
    this._addCss("DatePickerControl", "weekcolor", obj, ["normal"]);

    obj = new nexacro.Style_background("#eeeeeeff","","","0","0","0","0","true");
    this._addCss("DatePickerControl", "weekbackground", obj, ["normal"]);

    obj = new nexacro.Style_value("1 solid #dddddd");
    this._addCss("DatePickerControl", "weekborder", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 29 Droid Sans");
    this._addCss("DatePickerControl", "weekfont", obj, ["normal"]);

    obj = new nexacro.Style_color("#f57f50");
    this._addCss("DatePickerControl", "todaycolor", obj, ["normal"]);

    obj = new nexacro.Style_background("#ffffffff","","","0","0","0","0","true");
    this._addCss("DatePickerControl", "todaybackground", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 27 Droid Sans");
    this._addCss("DatePickerControl", "todayfont", obj, ["normal"]);

    obj = new nexacro.Style_background("","","","0","0","0","0","true");
    this._addCss("DatePickerControl", "saturdaybackground", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 27 Droid Sans");
    this._addCss("DatePickerControl", "saturdayfont", obj, ["normal"]);

    obj = new nexacro.Style_color("#0078e6");
    this._addCss("DatePickerControl", "saturdaycolor", obj, ["normal"]);

    obj = new nexacro.Style_color("#e4007f");
    this._addCss("DatePickerControl", "sundaycolor", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 27 Droid Sans");
    this._addCss("DatePickerControl", "sundayfont", obj, ["normal"]);

    obj = new nexacro.Style_color("#ffffff");
    this._addCss("DatePickerControl", "saturdaycolor", obj, ["mouseover", "focused", "selected"]);

    obj = new nexacro.Style_background("#f57f50ff","","","0","0","0","0","true");
    this._addCss("DatePickerControl", "saturdaybackground", obj, ["mouseover", "focused", "selected"]);

    obj = new nexacro.Style_color("#ffffff");
    this._addCss("DatePickerControl", "sundaycolor", obj, ["mouseover", "focused", "selected"]);

    obj = new nexacro.Style_background("#f57f50ff","","","0","0","0","0","true");
    this._addCss("DatePickerControl", "sundaybackground", obj, ["mouseover", "focused", "selected"]);

    obj = new nexacro.Style_value("transparent");
    this._addCss("Edit", "selectbackground", obj, ["normal"]);
    this._addCss("MaskEdit", "selectbackground", obj, ["normal"]);
    this._addCss("TextArea", "selectbackground", obj, ["normal", "mouseover", "focused"]);

    obj = new nexacro.Style_value("#f57f50");
    this._addCss("Edit", "selectbackground", obj, ["selected"]);
    this._addCss("MaskEdit", "selectbackground", obj, ["selected"]);
    this._addCss("TextArea", "selectbackground", obj, ["selected"]);

    obj = new nexacro.Style_border("1","solid","#c3c3c3ff","");
    this._addCss("Grid", "border", obj, ["normal"]);
    this._addCss("Static.sta_WF_MonthCalBg", "border", obj, ["normal"]);

    obj = new nexacro.Style_background("#656574ff","","","0","0","0","0","true");
    this._addCss("Grid>#head", "background", obj, ["normal"]);
    this._addCss("Grid>#controlbutton", "background", obj, ["normal"]);
    this._addCss("Button.btn_WF_Function", "background", obj, ["normal"]);
    this._addCss("Static.sta_WF_PopCalTitle", "background", obj, ["normal"]);

    obj = new nexacro.Style_align("center middle");
    this._addCss("Grid>#head", "cellalign", obj, ["normal"]);
    this._addCss("Grid>#body", "cellalign", obj, ["normal"]);

    obj = new nexacro.Style_background("#656574ff","","","0","0","0","0","true");
    this._addCss("Grid>#head", "cellbackground", obj, ["normal"]);

    obj = new nexacro.Style_background("#656574ff","","","0","0","0","0","true");
    this._addCss("Grid>#head", "cellbackground2", obj, ["normal"]);

    obj = new nexacro.Style_color("#ffffff");
    this._addCss("Grid>#head", "cellcolor", obj, ["normal"]);

    obj = new nexacro.Style_color("#ffffff");
    this._addCss("Grid>#head", "cellcolor2", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 17 Droid Sans");
    this._addCss("Grid>#head", "cellfont", obj, ["normal"]);
    this._addCss("Grid>#body", "cellfont", obj, ["normal"]);

    obj = new nexacro.Style_border("1","solid","#82828eff","");
    this._addCss("Grid>#head", "cellline", obj, ["normal"]);

    obj = new nexacro.Style_background("#ffffffff","","","0","0","0","0","true");
    this._addCss("Grid>#body", "cellbackground", obj, ["normal"]);
    this._addCss("Grid.grd_WF_MonthCal>#body", "cellbackground", obj, ["normal"]);

    obj = new nexacro.Style_background("#ffffffff","","","0","0","0","0","true");
    this._addCss("Grid>#body", "cellbackground2", obj, ["normal"]);
    this._addCss("Grid.grd_WF_MonthCal>#body", "cellbackground2", obj, ["normal"]);

    obj = new nexacro.Style_color("#555555");
    this._addCss("Grid>#body", "cellcolor", obj, ["normal"]);
    this._addCss("Grid.grd_WF_MonthCal>#body", "cellcolor", obj, ["normal"]);

    obj = new nexacro.Style_color("#555555");
    this._addCss("Grid>#body", "cellcolor2", obj, ["normal"]);

    obj = new nexacro.Style_padding("1 1 1 1");
    this._addCss("Grid>#body", "cellpadding", obj, ["normal"]);

    obj = new nexacro.Style_border("1","solid","#c3c3c3ff","");
    this._addCss("Grid>#body", "cellline", obj, ["normal"]);
    this._addCss(".CellGrd_WF_LabelGray", "cellline", obj, ["normal"]);
    this._addCss(".CellGrd_WF_LabelIndigo", "cellline", obj, ["normal"]);
    this._addCss(".CellGrd_WF_LabelWhite", "cellline", obj, ["normal"]);

    obj = new nexacro.Style_value("#fdfae9");
    this._addCss("Grid>#body", "selectbackground", obj, ["normal"]);

    obj = new nexacro.Style_color("#555555");
    this._addCss("Grid>#body", "selectcolor", obj, ["normal"]);
    this._addCss(".CellGrd_WF_LabelGray", "selectcolor", obj, ["normal"]);
    this._addCss(".CellGrd_WF_LabelWhite", "selectcolor", obj, ["normal"]);
    this._addCss("Grid.grd_WF_MonthCal>#body", "selectcolor", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 17 Droid Sans");
    this._addCss("Grid>#body", "selectfont", obj, ["normal"]);

    obj = new nexacro.Style_value("1 solid #9a9a9a");
    this._addCss("Grid>#controlcheckbox", "buttonborder", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_align("right middle");
    this._addCss("Grid>#controlmaskedit", "align", obj, ["normal"]);
    this._addCss("MaskEdit", "align", obj, ["normal"]);
    this._addCss(".CellGrd_WF_LabelWhite", "align", obj, ["normal"]);
    this._addCss(".CellGrd_WF_ColorRed", "align", obj, ["normal"]);
    this._addCss(".CellGrd_WF_ColorBlue", "align", obj, ["normal"]);

    obj = new nexacro.Style_padding("0 10 0 5");
    this._addCss("Grid>#controlmaskedit", "padding", obj, ["normal"]);
    this._addCss("MaskEdit", "padding", obj, ["normal"]);
    this._addCss(".CellGrd_WF_ColorBlue", "padding", obj, ["normal"]);

    obj = new nexacro.Style_border("1","solid","#4b4b5aff","");
    this._addCss("Grid>#controlbutton", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_Function", "border", obj, ["normal", "pushed"]);
    this._addCss("Button.btn_WF_Phone", "border", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("#414153ff","","","0","0","0","0","true");
    this._addCss("Grid>#controlbutton", "background", obj, ["pushed"]);
    this._addCss("Button.btn_WF_Function", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("","theme://images/grid_arrow.png","","0","0","50","50","true");
    this._addCss("Grid>#controlexpand", "background", obj, ["normal"]);

    obj = new nexacro.Style_align("cetner middle");
    this._addCss("ImageViewer", "align", obj, ["normal"]);

    obj = new nexacro.Style_value("left middle");
    this._addCss("Radio", "buttonalign", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_value("1 solid #9a9a9a");
    this._addCss("Radio", "buttonborder", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_value("URL('theme://Image/rdo_WF_BtnImg.png')");
    this._addCss("Radio", "buttonimage", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_value("3");
    this._addCss("Static", "linespace", obj, ["normal"]);

    obj = new nexacro.Style_background("#bbbbbbff","","","0","0","0","0","true");
    this._addCss("VScrollBarControl", "background", obj, ["normal"]);
    this._addCss("HScrollBarControl", "background", obj, ["normal"]);

    obj = new nexacro.Style_value("1");
    this._addCss("VScrollBarControl", "scrollbarsize", obj, ["normal"]);
    this._addCss("HScrollBarControl", "scrollbarsize", obj, ["normal"]);

    obj = new nexacro.Style_value("");
    this._addCss("VScrollBarControl", "trackbarsize", obj, ["normal"]);
    this._addCss("HScrollBarControl", "trackbarsize", obj, ["normal"]);

    obj = new nexacro.Style_value("0");
    this._addCss("VScrollBarControl", "decbtnsize", obj, ["normal"]);
    this._addCss("HScrollBarControl", "decbtnsize", obj, ["normal"]);

    obj = new nexacro.Style_value("0");
    this._addCss("VScrollBarControl", "incbtnsize", obj, ["normal"]);
    this._addCss("HScrollBarControl", "incbtnsize", obj, ["normal"]);

    obj = new nexacro.Style_background("#999999ff","","","0","0","0","0","true");
    this._addCss("VScrollBarControl>#trackbar", "background", obj, ["normal"]);
    this._addCss("HScrollBarControl>#trackbar", "background", obj, ["normal"]);

    obj = new nexacro.Style_value("#666666");
    this._addCss("VScrollBarControl>#trackbar", "bbackground", obj, ["pushed"]);

    obj = new nexacro.Style_background("#666666ff","","","0","0","0","0","true");
    this._addCss("HScrollBarControl>#trackbar", "background", obj, ["pushed"]);

    obj = new nexacro.Style_border("2","solid","#c7c6beff","","0","none","","","0","none","","","0","none","","");
    this._addCss("Tab", "border", obj, ["normal"]);

    obj = new nexacro.Style_background("@gradation","","","0","0","0","0","true");
    this._addCss("Tab", "buttonbackground", obj, ["normal"]);

    obj = new nexacro.Style_gradation("linear 0,0 #ebf8df 0,100 #f9fff3");
    this._addCss("Tab", "buttongradation", obj, ["normal"]);

    obj = new nexacro.Style_value("1 solid #b6b6b6ff");
    this._addCss("Tab", "buttonborder", obj, ["normal"]);

    obj = new nexacro.Style_bordertype("round","5","5","true","true","false","false");
    this._addCss("Tab", "buttonbordertype", obj, ["normal"]);

    obj = new nexacro.Style_padding("20 20 20 20");
    this._addCss("Tab", "buttonpadding", obj, ["normal"]);

    obj = new nexacro.Style_margin("0 5 0 0");
    this._addCss("Tab", "buttonmargin", obj, ["normal"]);

    obj = new nexacro.Style_color("#484848");
    this._addCss("Tab", "color", obj, ["normal"]);

    obj = new nexacro.Style_background("","theme://images/btn_tab_S.png","","0","0","0","0","true");
    this._addCss("Tab", "background", obj, ["selected", "focused"]);

    obj = new nexacro.Style_color("#046b40");
    this._addCss("Tab", "color", obj, ["selected", "focused"]);

    obj = new nexacro.Style_background("#f57f50ff","theme://Image/btn_WF_Search.png","","0","0","0","50","true");
    this._addCss("Button.btn_WF_Search", "background", obj, ["normal"]);

    obj = new nexacro.Style_border("1","solid","#bb5831ff","");
    this._addCss("Button.btn_WF_Search", "border", obj, ["normal"]);

    obj = new nexacro.Style_padding("0 0 0 37");
    this._addCss("Button.btn_WF_Search", "padding", obj, ["normal"]);

    obj = new nexacro.Style_background("#eb632dff","theme://Image/btn_WF_Search.png","","0","0","0","50","true");
    this._addCss("Button.btn_WF_Search", "background", obj, ["pushed"]);

    obj = new nexacro.Style_border("1","solid","#ad3809ff","");
    this._addCss("Button.btn_WF_Search", "border", obj, ["pushed"]);

    obj = new nexacro.Style_background("#f8f8f8ff","theme://Image/btn_WF_DownMove.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_DownMove", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f0f0f0ff","theme://Image/btn_WF_DownMoveP.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_DownMove", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#f8f8f8ff","theme://Image/btn_WF_UpMove.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_UpMove", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f0f0f0ff","theme://Image/btn_WF_UpMoveP.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_UpMove", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#f8f8f8ff","theme://Image/btn_WF_SpinMinus.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_SpinMinus", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f0f0f0ff","theme://Image/btn_WF_SpinMinusP.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_SpinMinus", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#f8f8f8ff","theme://Image/btn_WF_SpinPlus.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_SpinPlus", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f0f0f0ff","theme://Image/btn_WF_SpinPlusP.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_SpinPlus", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("","theme://Image/cal_WF_PreBtnP.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_MonthCalPreBtn", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("","theme://Image/cal_WF_NextBtnP.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_MonthCalNextBtn", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("","theme://Image/btn_WF_TabTFOnBg.png","stretch","5","9","0","0","true");
    this._addCss("Button.btn_WF_TabTFOn", "background", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_padding("-6 0 0 0");
    this._addCss("Button.btn_WF_TabTFOn", "padding", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_value("URL('theme://Image/btn_WF_TabTFOnImg.png')");
    this._addCss("Button.btn_WF_TabTFOn", "image", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_align("center bottom");
    this._addCss("Button.btn_WF_TabTFOn", "imagealign", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("","theme://Image/btn_WF_TabTFOffBg.png","stretch","5","9","0","0","true");
    this._addCss("Button.btn_WF_TabTFOff", "background", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_padding("0 0 8 0");
    this._addCss("Button.btn_WF_TabTFOff", "padding", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("#656574ff","","","0","0","0","0","true");
    this._addCss("Button.btn_WF_TabMFOn", "background", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_border("2","solid","#908f8fff","","2","solid","#908f8fff","","0","none","","","2","solid","#908f8fff","");
    this._addCss("Button.btn_WF_TabMFOn", "border", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("#e6e6e6ff","","","0","0","0","0","true");
    this._addCss("Button.btn_WF_TabMFOff", "background", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_border("1","solid","#aaaaaaff","","1","solid","#aaaaaaff","","2","solid","#908f8fff","","1","solid","#aaaaaaff","");
    this._addCss("Button.btn_WF_TabMFOff", "border", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("","theme://Image/btn_WF_EdtSearch.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_EdtSearch", "background", obj, ["normal", "pushed"]);

    obj = new nexacro.Style_background("#656574ff","theme://Image/btn_WF_Phone.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_Phone", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#414153ff","theme://Image/btn_WF_Phone.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_Phone", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#f8f8f8ff","theme://Image/btn_WF_PrevMove.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_PrevMove", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f0f0f0ff","theme://Image/btn_WF_PrevMoveP.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_PrevMove", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#f8f8f8ff","theme://Image/btn_WF_NextMove.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_NextMove", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f0f0f0ff","theme://Image/btn_WF_NextMoveP.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_NextMove", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#818181ff","theme://Image/btn_WF_More.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_More", "background", obj, ["normal"]);

    obj = new nexacro.Style_padding("0 0 0 56");
    this._addCss("Button.btn_WF_More", "padding", obj, ["normal"]);

    obj = new nexacro.Style_background("#818181ff","theme://Image/btn_WF_MoreP.png","","0","0","50","50","true");
    this._addCss("Button.btn_WF_More", "background", obj, ["pushed"]);

    obj = new nexacro.Style_color("#c0c0c0");
    this._addCss("Button.btn_WF_More", "color", obj, ["pushed"]);

    obj = new nexacro.Style_background("","theme://Image/btn_WF_Top.png","","0","0","0","0","true");
    this._addCss("Button.btn_WF_Top", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("","theme://Image/btn_WF_TopP.png","","0","0","0","0","true");
    this._addCss("Button.btn_WF_Top", "background", obj, ["pushed"]);

    obj = new nexacro.Style_background("#edededff","","","0","0","0","0","true");
    this._addCss(".CellGrd_WF_LabelGray", "background", obj, ["normal"]);
    this._addCss("Static.sta_WFSA_LabelBg", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#edededff","","","0","0","0","0","true");
    this._addCss(".CellGrd_WF_LabelGray", "background2", obj, ["normal"]);

    obj = new nexacro.Style_value("#ededed");
    this._addCss(".CellGrd_WF_LabelGray", "selectbackground", obj, ["normal"]);

    obj = new nexacro.Style_background("#74748aff","","","0","0","0","0","true");
    this._addCss(".CellGrd_WF_LabelIndigo", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#74748aff","","","0","0","0","0","true");
    this._addCss(".CellGrd_WF_LabelIndigo", "background2", obj, ["normal"]);

    obj = new nexacro.Style_value("#74748a");
    this._addCss(".CellGrd_WF_LabelIndigo", "selectbackground", obj, ["normal"]);

    obj = new nexacro.Style_color("#ffffff");
    this._addCss(".CellGrd_WF_LabelIndigo", "color2", obj, ["normal"]);

    obj = new nexacro.Style_color("#ffffff");
    this._addCss(".CellGrd_WF_LabelIndigo", "selectcolor", obj, ["normal"]);

    obj = new nexacro.Style_value("#ffffff");
    this._addCss(".CellGrd_WF_LabelWhite", "selectbackground", obj, ["normal"]);

    obj = new nexacro.Style_padding("0 10 0 10");
    this._addCss(".CellGrd_WF_LabelWhite", "padding", obj, ["normal"]);
    this._addCss(".CellGrd_WF_ColorRed", "padding", obj, ["normal"]);
    this._addCss("MaskEdit.msk_WF_Spin", "padding", obj, ["normal"]);

    obj = new nexacro.Style_background("","","","0","0","0","0","true");
    this._addCss(".CellGrd_WF_ColorRed", "background2", obj, ["normal"]);
    this._addCss(".CellGrd_WF_ColorBlue", "background2", obj, ["normal"]);

    obj = new nexacro.Style_color("#ca2727");
    this._addCss(".CellGrd_WF_ColorRed", "color", obj, ["normal"]);

    obj = new nexacro.Style_color("#ca2727");
    this._addCss(".CellGrd_WF_ColorRed", "color2", obj, ["normal"]);

    obj = new nexacro.Style_color("#ca2727");
    this._addCss(".CellGrd_WF_ColorRed", "selectcolor", obj, ["normal"]);

    obj = new nexacro.Style_color("#1f5bc9");
    this._addCss(".CellGrd_WF_ColorBlue", "color", obj, ["normal"]);

    obj = new nexacro.Style_color("#1f5bc9");
    this._addCss(".CellGrd_WF_ColorBlue", "color2", obj, ["normal"]);

    obj = new nexacro.Style_color("#1f5bc9");
    this._addCss(".CellGrd_WF_ColorBlue", "selectcolor", obj, ["normal"]);

    obj = new nexacro.Style_align("center bottom");
    this._addCss("Grid.grd_WF_MonthCal>#body", "cellalign", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 27 Droid Sans");
    this._addCss("Grid.grd_WF_MonthCal>#body", "cellfont", obj, ["normal"]);

    obj = new nexacro.Style_padding("0 0 0 0");
    this._addCss("Grid.grd_WF_MonthCal>#body", "cellpadding", obj, ["normal"]);

    obj = new nexacro.Style_border("0","none","","");
    this._addCss("Grid.grd_WF_MonthCal>#body", "cellline", obj, ["normal"]);
    this._addCss("Grid.grd_WF_SumType>#body", "cellline", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 27 Droid Sans");
    this._addCss("Grid.grd_WF_MonthCal>#body", "selectfont", obj, ["normal"]);

    obj = new nexacro.Style_border("1","solid","#c3c3c3ff","","0","none","","");
    this._addCss("Grid.grd_WF_SumType", "border", obj, ["normal"]);
    this._addCss("Grid.grd_WF_Default2", "border", obj, ["normal"]);
    this._addCss("Static.sta_WFSA_LabelBg", "border", obj, ["normal"]);

    obj = new nexacro.Style_align("left middle");
    this._addCss("Grid.grd_WF_SumType>#body", "cellalign", obj, ["normal"]);
    this._addCss("Grid.grd_WF_Default2>#body", "cellalign", obj, ["normal"]);
    this._addCss("Grid.grd_WF_SubMenuList>#body", "cellalign", obj, ["normal"]);

    obj = new nexacro.Style_background("","","","0","0","0","0","true");
    this._addCss("Grid.grd_WF_SumType>#body", "cellbackground", obj, ["normal"]);

    obj = new nexacro.Style_background("","","","0","0","0","0","true");
    this._addCss("Grid.grd_WF_SumType>#body", "cellbackground2", obj, ["normal"]);

    obj = new nexacro.Style_padding("0 10 0 10");
    this._addCss("Grid.grd_WF_SumType>#body", "cellpadding", obj, ["normal"]);

    obj = new nexacro.Style_margin("10 0 10 0");
    this._addCss("Grid.grd_WF_SumType>#body", "margin", obj, ["normal"]);

    obj = new nexacro.Style_border("1","solid","#c3c3c3ff","","0","none","","");
    this._addCss("Grid.grd_WF_Default2>#body", "cellline", obj, ["normal"]);
    this._addCss("Grid.grd_WF_SubMenuList>#body", "cellline", obj, ["normal"]);

    obj = new nexacro.Style_background("#f9f9f9ff","","","0","0","0","0","true");
    this._addCss("Grid.grd_WF_SubMenuList>#body", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#f9f9f9ff","theme://Image/grd_WF_SubMenuListBlit.png","","0","0","0","50","true");
    this._addCss("Grid.grd_WF_SubMenuList>#body", "cellbackground", obj, ["normal"]);

    obj = new nexacro.Style_background("#f9f9f9ff","theme://Image/grd_WF_SubMenuListBlit.png","","0","0","0","50","true");
    this._addCss("Grid.grd_WF_SubMenuList>#body", "cellbackground2", obj, ["normal"]);

    obj = new nexacro.Style_padding("1 10 1 34");
    this._addCss("Grid.grd_WF_SubMenuList>#body", "cellpadding", obj, ["normal"]);

    obj = new nexacro.Style_value("#ededed URL('theme://Image/grd_WF_SubMenuListBlit.png') left middle");
    this._addCss("Grid.grd_WF_SubMenuList>#body", "selectbackground", obj, ["normal"]);

    obj = new nexacro.Style_color("#f26c38");
    this._addCss("Grid.grd_WF_SubMenuList>#body", "selectcolor", obj, ["normal"]);

    obj = new nexacro.Style_background("#3a3a43ff","","","0","0","0","0","true");
    this._addCss("Static.sta_WF_TopLine", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("","theme://Image/sta_WF_LabelBlit.png","","0","0","0","50","true");
    this._addCss("Static.sta_WF_Label01", "background", obj, ["normal"]);
    this._addCss("Static.sta_WF_Label02", "background", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 20 Droid Sans");
    this._addCss("Static.sta_WF_Label01", "font", obj, ["normal"]);

    obj = new nexacro.Style_color("#f26c38");
    this._addCss("Static.sta_WF_Label01", "color", obj, ["normal"]);

    obj = new nexacro.Style_padding("0 0 0 25");
    this._addCss("Static.sta_WF_Label01", "padding", obj, ["normal"]);
    this._addCss("Static.sta_WF_Label02", "padding", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 34 Droid Sans");
    this._addCss("Static.sta_WF_PopCalTitle", "font", obj, ["normal"]);
    this._addCss("Static.sta_WF_MonthCalTitle", "font", obj, ["normal"]);

    obj = new nexacro.Style_background("#747482ff","","","0","0","0","0","true");
    this._addCss("Static.sta_WF_MonthCalTitle", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#fffcedff","theme://Image/sta_WF_WebzineImage.png","","0","0","50","100","true");
    this._addCss("Static.sta_WF_WebzineBg", "background", obj, ["normal"]);

    obj = new nexacro.Style_border("2","solid","#3a3a43ff","","0","none","","","4","solid","#4c4743ff","","0","none","","");
    this._addCss("Static.sta_WF_WebzineBg", "border", obj, ["normal"]);

    obj = new nexacro.Style_align("center bottom");
    this._addCss("Static.sta_WF_WebzineText", "align", obj, ["normal"]);

    obj = new nexacro.Style_font("bold antialias 13 Droid Sans");
    this._addCss("Static.sta_WF_WebzineText", "font", obj, ["normal"]);

    obj = new nexacro.Style_background("#ebebebff","","","0","0","0","0","true");
    this._addCss("Static.sta_WF_WebzineImgBg", "background", obj, ["normal"]);

    obj = new nexacro.Style_border("1","solid","#dadadaff","");
    this._addCss("Static.sta_WF_WebzineImg", "border", obj, ["normal"]);

    obj = new nexacro.Style_background("#6ce2caff","","","0","0","0","0","true");
    this._addCss("Static.sta_GUIDE_Area", "background", obj, ["normal"]);

    obj = new nexacro.Style_font("9 Dotum");
    this._addCss("Static.sta_GUIDE_Area", "font", obj, ["normal"]);
    this._addCss("Static.sta_GUIDE_Area2", "font", obj, ["normal"]);
    this._addCss("Static.sta_GUIDE_BlackText", "font", obj, ["normal"]);
    this._addCss("Static.sta_GUIDE_RedText", "font", obj, ["normal"]);

    obj = new nexacro.Style_value("70");
    this._addCss("Static.sta_GUIDE_Area", "opacity", obj, ["normal"]);
    this._addCss("Static.sta_GUIDE_Area2", "opacity", obj, ["normal"]);

    obj = new nexacro.Style_background("#f091b3ff","","","0","0","0","0","true");
    this._addCss("Static.sta_GUIDE_Area2", "background", obj, ["normal"]);

    obj = new nexacro.Style_color("#ff4900");
    this._addCss("Static.sta_GUIDE_RedText", "color", obj, ["normal"]);

    obj = new nexacro.Style_font("bold 9 Dotum");
    this._addCss("Static.sta_GUIDE_BlackBoldText", "font", obj, ["normal"]);

    obj = null;
    
//[add theme images]
  };
})();
